export default function MobileHome() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100vh', flexDirection: 'column' }}>
      <h1>MarketDemo Mobile</h1>
      <p>Это упрощённая PWA‑версия маркетплейса. Дальнейшая реализация предполагает использование React Native или Expo.</p>
    </div>
  );
}