/*
 * Скрипт сидирования базы данных для демо. Использует пакет `pg` для прямого подключения к PostgreSQL.
 * Заполняет таблицы categories, products и product_variants тестовыми данными из общего пакета.
 */
import { Client } from 'pg';
import { categories, products } from '../../../packages/shared/src/data/catalog';

async function seed() {
  const client = new Client({
    host: process.env.POSTGRES_HOST || 'localhost',
    port: parseInt(process.env.POSTGRES_PORT || '5432'),
    user: process.env.POSTGRES_USER || 'marketdemo',
    password: process.env.POSTGRES_PASSWORD || 'marketdemo',
    database: process.env.POSTGRES_DB || 'marketdemo',
  });
  await client.connect();
  console.log('Connected to database');
  // Очистка
  await client.query('DELETE FROM variant_stock');
  await client.query('DELETE FROM product_variants');
  await client.query('DELETE FROM products');
  await client.query('DELETE FROM categories');
  // Категории
  for (const cat of categories) {
    await client.query('INSERT INTO categories(id, name, parent_id) VALUES($1, $2, $3)', [cat.id, cat.name, cat.parentId || null]);
  }
  console.log('Categories inserted');
  // Товары и вариации
  for (const product of products) {
    await client.query(
      'INSERT INTO products(sku, category_id, name, description, price, old_price, discount, rating) VALUES($1,$2,$3,$4,$5,$6,$7,$8)',
      [
        product.sku,
        product.categoryId,
        product.name,
        product.description,
        product.price,
        product.oldPrice || null,
        product.discount || null,
        product.rating || null,
      ],
    );
    for (const variant of product.variants) {
      await client.query(
        'INSERT INTO product_variants(id, product_sku, color, size, barcode) VALUES($1,$2,$3,$4,$5)',
        [variant.id, product.sku, variant.color || null, variant.size || null, variant.barcode],
      );
      for (const [warehouse, stock] of Object.entries(variant.stockByWarehouse)) {
        await client.query(
          'INSERT INTO variant_stock(variant_id, warehouse, stock) VALUES($1,$2,$3)',
          [variant.id, warehouse, stock],
        );
      }
    }
  }
  console.log('Products and variants inserted');
  await client.end();
  console.log('Seed completed');
}

seed().catch((err) => {
  console.error(err);
  process.exit(1);
});