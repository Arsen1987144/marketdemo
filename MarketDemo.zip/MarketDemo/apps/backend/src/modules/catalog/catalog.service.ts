import { Injectable, NotFoundException } from '@nestjs/common';
import { categories, products, Category, Product } from '../../../../packages/shared/src/data/catalog';

@Injectable()
export class CatalogService {
  /**
   * Возвращает список категорий.
   */
  getCategories(): Category[] {
    return categories;
  }

  /**
   * Возвращает товары по идентификатору категории. Если categoryId = undefined, возвращает все товары.
   */
  getProducts(categoryId?: string): Product[] {
    if (!categoryId) {
      return products;
    }
    return products.filter((p) => p.categoryId === categoryId);
  }

  /**
   * Возвращает товар по SKU.
   */
  getProductBySku(sku: string): Product {
    const prod = products.find((p) => p.sku === sku);
    if (!prod) {
      throw new NotFoundException(`Product with SKU ${sku} not found`);
    }
    return prod;
  }
}