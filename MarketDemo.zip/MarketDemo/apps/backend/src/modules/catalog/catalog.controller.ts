import { Controller, Get, Param, Query } from '@nestjs/common';
import { ApiOperation, ApiParam, ApiQuery, ApiTags } from '@nestjs/swagger';
import { CatalogService } from './catalog.service';
import { Category, Product } from '../../../../packages/shared/src/data/catalog';

@ApiTags('catalog')
@Controller('catalog')
export class CatalogController {
  constructor(private readonly catalogService: CatalogService) {}

  @Get('categories')
  @ApiOperation({ summary: 'Получить список всех категорий' })
  getCategories(): Category[] {
    return this.catalogService.getCategories();
  }

  @Get('products')
  @ApiOperation({ summary: 'Получить список товаров' })
  @ApiQuery({ name: 'categoryId', required: false, description: 'ID категории для фильтрации' })
  getProducts(@Query('categoryId') categoryId?: string): Product[] {
    return this.catalogService.getProducts(categoryId);
  }

  @Get('products/:sku')
  @ApiOperation({ summary: 'Получить товар по SKU' })
  @ApiParam({ name: 'sku', description: 'Артикул товара' })
  getProductBySku(@Param('sku') sku: string): Product {
    return this.catalogService.getProductBySku(sku);
  }
}