export default function AdminProducts() {
  return (
    <div style={{ padding: '2rem' }}>
      <h1>Товары</h1>
      <p>Страница для модерации и редактирования карточек товаров.</p>
    </div>
  );
}