export default function AdminReturns() {
  return (
    <div style={{ padding: '2rem' }}>
      <h1>Возвраты и споры</h1>
      <p>Здесь обрабатываются запросы на возврат товаров и разрешение споров с покупателями.</p>
    </div>
  );
}