export default function AdminPromotions() {
  return (
    <div style={{ padding: '2rem' }}>
      <h1>Промо‑акции</h1>
      <p>Управление скидками, купонами, промокодами и баннерными кампаниями.</p>
    </div>
  );
}