export default function AdminCategories() {
  return (
    <div style={{ padding: '2rem' }}>
      <h1>Категории</h1>
      <p>Здесь администратор сможет управлять деревом категорий и атрибутами.</p>
    </div>
  );
}