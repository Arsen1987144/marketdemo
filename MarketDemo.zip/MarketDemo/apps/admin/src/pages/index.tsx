import Head from 'next/head';
import Link from 'next/link';

export default function AdminDashboard() {
  return (
    <div style={{ padding: '2rem' }}>
      <Head>
        <title>MarketDemo – Админка</title>
      </Head>
      <h1>Административная панель</h1>
      <p>Эта панель предназначена для модераторов и администраторов. Здесь можно управлять категориями, товарами, заказами и пользователями.</p>
      <ul>
        <li><Link href="/categories">Категории</Link></li>
        <li><Link href="/products">Товары</Link></li>
        <li><Link href="/orders">Заказы</Link></li>
        <li><Link href="/returns">Возвраты</Link></li>
        <li><Link href="/promotions">Промо‑акции</Link></li>
      </ul>
    </div>
  );
}