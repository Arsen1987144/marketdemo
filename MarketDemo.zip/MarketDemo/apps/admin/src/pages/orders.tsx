export default function AdminOrders() {
  return (
    <div style={{ padding: '2rem' }}>
      <h1>Заказы</h1>
      <p>Мониторинг заказов по статусам, SLA и управление их жизненным циклом.</p>
    </div>
  );
}