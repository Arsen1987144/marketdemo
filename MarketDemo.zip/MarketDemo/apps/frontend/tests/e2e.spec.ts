import { test, expect } from '@playwright/test';

test.describe('MarketDemo buyer flows', () => {
  test('home page lists categories', async ({ page }) => {
    await page.goto('http://localhost:3000');
    await expect(page.locator('h1')).toHaveText(/Категории/);
    // Должна отображаться категория Одежда
    await expect(page.locator('a').filter({ hasText: 'Одежда' })).toHaveCount(1);
  });
  test('product page shows details', async ({ page }) => {
    // перехожу на продуктовый урл (SKU-0001) — он должен существовать в сид данных
    await page.goto('http://localhost:3000/product/SKU-0001');
    await expect(page.locator('h1')).toHaveText(/Футболка/);
    await expect(page.locator('button')).toHaveText(/Добавить в корзину/);
  });
});