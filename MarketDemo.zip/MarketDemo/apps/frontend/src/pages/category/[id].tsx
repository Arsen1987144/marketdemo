import { useRouter } from 'next/router';
import { useQuery } from '@tanstack/react-query';
import Head from 'next/head';
import Layout from '../../components/Layout';
import { fetchCategories, fetchProducts, Product, Category } from '../../utils/api';
import Link from 'next/link';

export default function CategoryPage() {
  const router = useRouter();
  const { id } = router.query as { id: string };
  const {
    data: categories,
    isLoading: catLoading,
  } = useQuery(['categories'], fetchCategories);
  const {
    data: products,
    isLoading: prodLoading,
  } = useQuery(['products', id], () => fetchProducts(id), { enabled: !!id });
  const categoryName = categories?.find((c: Category) => c.id === id)?.name || 'Категория';

  return (
    <Layout>
      <Head>
        <title>MarketDemo – {categoryName}</title>
      </Head>
      <h1 style={{ fontSize: '2rem', marginBottom: '1rem' }}>{categoryName}</h1>
      {(catLoading || prodLoading) && <p>Загрузка...</p>}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: '1rem' }}>
        {products?.map((product: Product) => (
          <Link key={product.sku} href={`/product/${product.sku}`}
            style={{ display: 'block', border: '1px solid #eee', borderRadius: '4px', padding: '0.5rem', backgroundColor: '#fff' }}>
              <img src={product.images[0]} alt={product.name} style={{ width: '100%', height: 'auto' }} />
              <h2 style={{ fontSize: '1rem', margin: '0.5rem 0' }}>{product.name}</h2>
              <p style={{ margin: '0', fontWeight: 'bold' }}>{product.price} ₽</p>
          </Link>
        ))}
      </div>
    </Layout>
  );
}