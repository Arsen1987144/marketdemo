import Head from 'next/head';
import Link from 'next/link';
import { useQuery } from '@tanstack/react-query';
import Layout from '../components/Layout';
import { fetchCategories, Category } from '../utils/api';

export default function Home() {
  const { data: categories, isLoading, error } = useQuery(['categories'], fetchCategories);

  return (
    <Layout>
      <Head>
        <title>MarketDemo – Каталог</title>
      </Head>
      <h1 style={{ fontSize: '2rem', marginBottom: '1rem' }}>Категории</h1>
      {isLoading && <p>Загрузка...</p>}
      {error && <p>Ошибка при загрузке данных</p>}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(150px, 1fr))', gap: '0.5rem' }}>
        {categories?.map((cat: Category) => (
          <Link key={cat.id} href={`/category/${cat.id}`}
            style={{ display: 'block', padding: '1rem', backgroundColor: '#fff', border: '1px solid #ddd', borderRadius: '4px', textAlign: 'center' }}>
              {cat.name}
          </Link>
        ))}
      </div>
    </Layout>
  );
}