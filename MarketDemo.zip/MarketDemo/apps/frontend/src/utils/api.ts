import axios from 'axios';

const api = axios.create({
  baseURL: process.env.API_BASE_URL || 'http://localhost:4000/api',
});

export interface Category {
  id: string;
  name: string;
}

export interface ProductVariant {
  id: string;
  color?: string;
  size?: string;
  barcode: string;
  stockByWarehouse: Record<string, number>;
}

export interface Product {
  sku: string;
  categoryId: string;
  name: string;
  description: string;
  price: number;
  oldPrice?: number;
  discount?: number;
  rating?: number;
  images: string[];
  variants: ProductVariant[];
}

export const fetchCategories = async (): Promise<Category[]> => {
  const res = await api.get<Category[]>('/catalog/categories');
  return res.data;
};

export const fetchProducts = async (categoryId?: string): Promise<Product[]> => {
  const res = await api.get<Product[]>('/catalog/products', {
    params: categoryId ? { categoryId } : {},
  });
  return res.data;
};

export const fetchProduct = async (sku: string): Promise<Product> => {
  const res = await api.get<Product>(`/catalog/products/${sku}`);
  return res.data;
};