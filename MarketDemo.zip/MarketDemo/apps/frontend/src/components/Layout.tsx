import Link from 'next/link';
import React, { ReactNode } from 'react';

interface LayoutProps {
  children: ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  return (
    <div>
      <header style={{ backgroundColor: '#542ea9', padding: '1rem', color: '#fff' }}>
        <nav style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ fontSize: '1.5rem', fontWeight: 'bold' }}>
            <Link href="/">MarketDemo</Link>
          </div>
        </nav>
      </header>
      <main style={{ padding: '1rem' }}>{children}</main>
      <footer style={{ textAlign: 'center', padding: '1rem', backgroundColor: '#f1f1f1' }}>
        © {new Date().getFullYear()} MarketDemo. Все права защищены.
      </footer>
    </div>
  );
}