import Head from 'next/head';
import Link from 'next/link';

export default function SellerDashboard() {
  return (
    <div style={{ padding: '2rem' }}>
      <Head>
        <title>MarketDemo – Личный кабинет продавца</title>
      </Head>
      <h1>Кабинет продавца</h1>
      <p>Добро пожаловать в демо‑кабинет продавца. Здесь в дальнейшем можно будет загружать товары, управлять заказами и просматривать отчёты.</p>
      <ul>
        <li>
          <Link href="/products">Товары</Link>
        </li>
        <li>
          <Link href="/orders">Заказы</Link>
        </li>
        <li>
          <Link href="/finance">Финансы</Link>
        </li>
      </ul>
    </div>
  );
}