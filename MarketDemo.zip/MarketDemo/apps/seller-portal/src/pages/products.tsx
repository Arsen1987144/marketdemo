export default function SellerProducts() {
  return (
    <div style={{ padding: '2rem' }}>
      <h1>Товары</h1>
      <p>Здесь в будущем будет интерфейс для загрузки и редактирования товаров продавца.</p>
    </div>
  );
}