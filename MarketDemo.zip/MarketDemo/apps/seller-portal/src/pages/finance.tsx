export default function SellerFinance() {
  return (
    <div style={{ padding: '2rem' }}>
      <h1>Финансы</h1>
      <p>В этой секции появятся отчёты по продажам, комиссии маркетплейса и выплата.</p>
    </div>
  );
}