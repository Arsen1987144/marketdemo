export default function SellerOrders() {
  return (
    <div style={{ padding: '2rem' }}>
      <h1>Заказы</h1>
      <p>Страница управления заказами находится в разработке. Здесь продавец сможет отслеживать статус сборки и доставки.</p>
    </div>
  );
}